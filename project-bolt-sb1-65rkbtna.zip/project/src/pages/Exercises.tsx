import React, { useState } from 'react';
import { List, Play, Download, Clock, CheckCircle2, XCircle, AlertTriangle, MoveRight } from 'lucide-react';

interface Exercise {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  type: 'red-team' | 'blue-team' | 'purple-team';
  status: 'completed' | 'in-progress' | 'not-started';
  completion?: number;
}

const Exercises: React.FC = () => {
  const [exercises] = useState<Exercise[]>([
    {
      id: 'ex1',
      title: 'Basic Port Scanning & Enumeration',
      description: 'Learn how to discover and enumerate services on a target system',
      difficulty: 'beginner',
      duration: '30 min',
      type: 'red-team',
      status: 'completed',
      completion: 100,
    },
    {
      id: 'ex2',
      title: 'SQL Injection Attacks',
      description: 'Practice identifying and exploiting SQL injection vulnerabilities',
      difficulty: 'intermediate',
      duration: '45 min',
      type: 'red-team',
      status: 'in-progress',
      completion: 60,
    },
    {
      id: 'ex3',
      title: 'Intrusion Detection Configuration',
      description: 'Set up and configure Snort IDS rules for common attack vectors',
      difficulty: 'intermediate',
      duration: '1 hour',
      type: 'blue-team',
      status: 'in-progress',
      completion: 45,
    },
    {
      id: 'ex4',
      title: 'Incident Response Simulation',
      description: 'Respond to a simulated security breach and investigate the attack path',
      difficulty: 'advanced',
      duration: '2 hours',
      type: 'blue-team',
      status: 'not-started',
    },
    {
      id: 'ex5',
      title: 'Advanced Persistence Techniques',
      description: 'Learn and practice advanced persistence mechanisms on compromised systems',
      difficulty: 'advanced',
      duration: '1.5 hours',
      type: 'red-team',
      status: 'not-started',
    },
    {
      id: 'ex6',
      title: 'Full Attack Chain Simulation',
      description: 'Conduct a complete attack and defense exercise across multiple systems',
      difficulty: 'advanced',
      duration: '3 hours',
      type: 'purple-team',
      status: 'not-started',
    },
  ]);
  
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  
  const difficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner':
        return 'bg-success/20 text-success';
      case 'intermediate':
        return 'bg-warning/20 text-warning';
      case 'advanced':
        return 'bg-accent/20 text-accent';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };
  
  const typeColor = (type: string) => {
    switch (type) {
      case 'red-team':
        return 'bg-accent/20 text-accent';
      case 'blue-team':
        return 'bg-secondary/20 text-secondary';
      case 'purple-team':
        return 'bg-primary/20 text-primary';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };
  
  const statusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="h-5 w-5 text-success" />;
      case 'in-progress':
        return <Clock className="h-5 w-5 text-warning" />;
      case 'not-started':
        return <XCircle className="h-5 w-5 text-muted-foreground" />;
      default:
        return null;
    }
  };
  
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Training Exercises</h1>
        <p className="text-muted-foreground">
          Practice your offensive and defensive security skills
        </p>
      </div>
      
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="rounded-lg border border-border bg-card overflow-hidden">
            <div className="p-6 border-b border-border">
              <h2 className="text-xl font-semibold flex items-center">
                <List className="h-5 w-5 mr-2 text-primary" />
                Available Exercises
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Select an exercise to view details or start training
              </p>
            </div>
            
            <div className="divide-y divide-border">
              {exercises.map((exercise) => (
                <div
                  key={exercise.id}
                  className={`p-4 transition-colors hover:bg-muted/50 cursor-pointer ${
                    selectedExercise?.id === exercise.id ? 'bg-muted' : ''
                  }`}
                  onClick={() => setSelectedExercise(exercise)}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center">
                        <h3 className="font-medium">{exercise.title}</h3>
                        {statusIcon(exercise.status)}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {exercise.description}
                      </p>
                      <div className="mt-2 flex items-center space-x-2">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${difficultyColor(
                            exercise.difficulty
                          )}`}
                        >
                          {exercise.difficulty}
                        </span>
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${typeColor(
                            exercise.type
                          )}`}
                        >
                          {exercise.type.replace('-', ' ')}
                        </span>
                        <span className="inline-flex items-center text-xs text-muted-foreground">
                          <Clock className="h-3 w-3 mr-1" />
                          {exercise.duration}
                        </span>
                      </div>
                    </div>
                    
                    {exercise.status === 'in-progress' && (
                      <div className="w-20">
                        <div className="text-xs text-right mb-1">
                          {exercise.completion}%
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full"
                            style={{ width: `${exercise.completion}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div>
          {selectedExercise ? (
            <div className="rounded-lg border border-border bg-card p-6 sticky top-24">
              <h2 className="text-xl font-semibold">{selectedExercise.title}</h2>
              <span
                className={`mt-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                  selectedExercise.status === 'completed'
                    ? 'bg-success/20 text-success'
                    : selectedExercise.status === 'in-progress'
                    ? 'bg-warning/20 text-warning'
                    : 'bg-muted text-muted-foreground'
                }`}
              >
                {selectedExercise.status.replace('-', ' ')}
              </span>
              
              <div className="mt-4 space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Description</h3>
                  <p className="mt-1 text-sm">{selectedExercise.description}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Type</h3>
                    <p className="mt-1 text-sm capitalize">{selectedExercise.type.replace('-', ' ')}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Difficulty</h3>
                    <p className="mt-1 text-sm capitalize">{selectedExercise.difficulty}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Duration</h3>
                    <p className="mt-1 text-sm">{selectedExercise.duration}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Completion</h3>
                    <p className="mt-1 text-sm">{selectedExercise.completion || 0}%</p>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Prerequisites</h3>
                  <ul className="space-y-1 text-sm">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-4 w-4 text-success mr-2 mt-0.5" />
                      Active lab environment
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-4 w-4 text-success mr-2 mt-0.5" />
                      Basic understanding of {selectedExercise.type.replace('-', ' ')} concepts
                    </li>
                    {selectedExercise.difficulty !== 'beginner' && (
                      <li className="flex items-start">
                        <AlertTriangle className="h-4 w-4 text-warning mr-2 mt-0.5" />
                        Completion of prerequisite exercises
                      </li>
                    )}
                  </ul>
                </div>
                
                <div className="pt-4 flex flex-col space-y-2">
                  {selectedExercise.status === 'not-started' ? (
                    <button
                      className="inline-flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Start Exercise
                    </button>
                  ) : selectedExercise.status === 'in-progress' ? (
                    <button
                      className="inline-flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Continue Exercise
                    </button>
                  ) : (
                    <button
                      className="inline-flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-foreground bg-muted hover:bg-muted/80 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-muted/50"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Restart Exercise
                    </button>
                  )}
                  
                  <button
                    className="inline-flex justify-center items-center py-2 px-4 border border-border rounded-md text-sm font-medium text-foreground hover:bg-muted focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download Instructions
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-border bg-card p-6 flex flex-col items-center justify-center text-center h-full">
              <List className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No Exercise Selected</h3>
              <p className="text-sm text-muted-foreground mt-2 mb-6">
                Select an exercise from the list to view details and begin training
              </p>
              <div className="flex items-center text-sm text-primary">
                <span>Browse exercises</span>
                <MoveRight className="h-4 w-4 ml-1" />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Exercises;