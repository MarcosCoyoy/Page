import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  BarChart4, 
  Calendar, 
  Clock, 
  Filter, 
  ChevronDown,
  AlertTriangle,
  Shield,
  Target,
  FileWarning,
  PieChart
} from 'lucide-react';

interface Report {
  id: string;
  title: string;
  type: 'security-assessment' | 'vulnerability-scan' | 'penetration-test' | 'compliance-audit' | 'incident-response';
  date: string;
  author: string;
  description: string;
  status: 'draft' | 'final';
  tags: string[];
}

const Reports: React.FC = () => {
  const [reports] = useState<Report[]>([
    {
      id: 'report1',
      title: 'Q2 2025 Security Assessment',
      type: 'security-assessment',
      date: '2025-04-05',
      author: 'Security Team',
      description: 'Quarterly security assessment of all systems and infrastructure',
      status: 'final',
      tags: ['quarterly', 'infrastructure', 'high-priority'],
    },
    {
      id: 'report2',
      title: 'Web Application Penetration Test',
      type: 'penetration-test',
      date: '2025-03-28',
      author: 'Red Team',
      description: 'Detailed penetration test of the main web application',
      status: 'final',
      tags: ['web-app', 'critical-findings'],
    },
    {
      id: 'report3',
      title: 'Network Vulnerability Scan',
      type: 'vulnerability-scan',
      date: '2025-04-01',
      author: 'Blue Team',
      description: 'Automated vulnerability scan of internal network',
      status: 'final',
      tags: ['network', 'monthly'],
    },
    {
      id: 'report4',
      title: 'Compliance Audit: PCI DSS',
      type: 'compliance-audit',
      date: '2025-03-15',
      author: 'Compliance Team',
      description: 'PCI DSS compliance audit for payment processing systems',
      status: 'final',
      tags: ['compliance', 'pci-dss'],
    },
    {
      id: 'report5',
      title: 'Incident Response: Brute Force Attack',
      type: 'incident-response',
      date: '2025-04-02',
      author: 'Blue Team',
      description: 'Analysis and response to brute force attack on admin interface',
      status: 'final',
      tags: ['incident', 'attack', 'remediation'],
    },
    {
      id: 'report6',
      title: 'Internal Security Controls Assessment',
      type: 'security-assessment',
      date: '2025-04-08',
      author: 'Security Team',
      description: 'Assessment of internal security controls and procedures',
      status: 'draft',
      tags: ['internal', 'controls', 'policies'],
    },
  ]);
  
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [selectedType, setSelectedType] = useState<string>('all');
  
  const typeIcon = (type: string) => {
    switch (type) {
      case 'security-assessment':
        return <Shield className="h-5 w-5" />;
      case 'vulnerability-scan':
        return <AlertTriangle className="h-5 w-5" />;
      case 'penetration-test':
        return <Target className="h-5 w-5" />;
      case 'compliance-audit':
        return <FileWarning className="h-5 w-5" />;
      case 'incident-response':
        return <FileText className="h-5 w-5" />;
      default:
        return <FileText className="h-5 w-5" />;
    }
  };
  
  const typeColor = (type: string) => {
    switch (type) {
      case 'security-assessment':
        return 'bg-primary/20 text-primary';
      case 'vulnerability-scan':
        return 'bg-warning/20 text-warning';
      case 'penetration-test':
        return 'bg-accent/20 text-accent';
      case 'compliance-audit':
        return 'bg-secondary/20 text-secondary';
      case 'incident-response':
        return 'bg-error/20 text-error';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };
  
  const filteredReports = selectedType === 'all'
    ? reports
    : reports.filter(report => report.type === selectedType);
  
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
        <p className="text-muted-foreground">
          View and download security reports and assessments
        </p>
      </div>
      
      <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
        <div className="relative">
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-border rounded-md bg-card text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filter by Type
            <ChevronDown className="h-4 w-4 ml-2" />
          </button>
          
          <div className="absolute z-10 mt-2 w-56 rounded-md bg-card shadow-lg p-2 border border-border">
            <div className="py-1">
              <button
                className={`block px-4 py-2 text-sm rounded-md w-full text-left ${
                  selectedType === 'all' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setSelectedType('all')}
              >
                All Reports
              </button>
              <button
                className={`block px-4 py-2 text-sm rounded-md w-full text-left ${
                  selectedType === 'security-assessment' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setSelectedType('security-assessment')}
              >
                Security Assessment
              </button>
              <button
                className={`block px-4 py-2 text-sm rounded-md w-full text-left ${
                  selectedType === 'vulnerability-scan' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setSelectedType('vulnerability-scan')}
              >
                Vulnerability Scan
              </button>
              <button
                className={`block px-4 py-2 text-sm rounded-md w-full text-left ${
                  selectedType === 'penetration-test' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setSelectedType('penetration-test')}
              >
                Penetration Test
              </button>
              <button
                className={`block px-4 py-2 text-sm rounded-md w-full text-left ${
                  selectedType === 'compliance-audit' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setSelectedType('compliance-audit')}
              >
                Compliance Audit
              </button>
              <button
                className={`block px-4 py-2 text-sm rounded-md w-full text-left ${
                  selectedType === 'incident-response' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setSelectedType('incident-response')}
              >
                Incident Response
              </button>
            </div>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <button
            className="inline-flex items-center py-2 px-3 border border-border rounded-md text-sm font-medium bg-card hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <Calendar className="h-4 w-4 mr-2" />
            Sort by Date
          </button>
          
          <button
            className="inline-flex items-center py-2 px-3 border border-border rounded-md text-sm font-medium bg-card hover:bg-muted focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <FileText className="h-4 w-4 mr-2" />
            Generate Report
          </button>
        </div>
      </div>
      
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-lg border border-border bg-card">
          <div className="p-6 border-b border-border">
            <h2 className="text-xl font-semibold flex items-center">
              <FileText className="h-5 w-5 mr-2 text-primary" />
              Available Reports
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              View and download detailed security reports
            </p>
          </div>
          
          <div className="divide-y divide-border">
            {filteredReports.map((report) => (
              <div
                key={report.id}
                className={`p-4 transition-colors hover:bg-muted/50 cursor-pointer ${
                  selectedReport?.id === report.id ? 'bg-muted' : ''
                }`}
                onClick={() => setSelectedReport(report)}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center">
                      <h3 className="font-medium">{report.title}</h3>
                      {report.status === 'draft' && (
                        <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground">
                          Draft
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {report.description}
                    </p>
                    <div className="mt-2 flex items-center space-x-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${typeColor(
                          report.type
                        )}`}
                      >
                        <span className="mr-1">{typeIcon(report.type)}</span>
                        {report.type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                      </span>
                      <span className="text-xs text-muted-foreground flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {report.date}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        By {report.author}
                      </span>
                    </div>
                  </div>
                  <div>
                    <button
                      className="inline-flex items-center p-1 border border-transparent rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
                    >
                      <Download className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            
            {filteredReports.length === 0 && (
              <div className="p-6 text-center text-muted-foreground">
                No reports matching the selected filter
              </div>
            )}
          </div>
        </div>
        
        <div>
          {selectedReport ? (
            <div className="rounded-lg border border-border bg-card p-6 sticky top-24">
              <div className="flex justify-between items-start">
                <h2 className="text-xl font-semibold">{selectedReport.title}</h2>
                <span
                  className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${typeColor(
                    selectedReport.type
                  )}`}
                >
                  {selectedReport.type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </span>
              </div>
              
              <div className="mt-4 space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Description</h3>
                  <p className="mt-1 text-sm">{selectedReport.description}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Date</h3>
                    <p className="mt-1 text-sm">{selectedReport.date}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Author</h3>
                    <p className="mt-1 text-sm">{selectedReport.author}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                    <p className="mt-1 text-sm capitalize">{selectedReport.status}</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Tags</h3>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {selectedReport.tags.map((tag) => (
                      <span
                        key={tag}
                        className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-foreground"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Report Preview</h3>
                  <div className="relative border border-border rounded-md overflow-hidden h-40 bg-muted/50">
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                      <FileText className="h-12 w-12 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground text-center">
                        Preview not available. Download the report to view its contents.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 flex flex-col space-y-2">
                  <button
                    className="inline-flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download Report
                  </button>
                  
                  <button
                    className="inline-flex justify-center items-center py-2 px-4 border border-border rounded-md text-sm font-medium text-foreground hover:bg-muted focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    View Online
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-border bg-card p-6 flex flex-col items-center justify-center text-center h-72">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No Report Selected</h3>
              <p className="text-sm text-muted-foreground mt-2">
                Select a report from the list to view details and options
              </p>
            </div>
          )}
          
          <div className="mt-6 rounded-lg border border-border bg-card p-6">
            <h2 className="text-xl font-semibold flex items-center mb-4">
              <BarChart4 className="h-5 w-5 mr-2 text-primary" />
              Report Statistics
            </h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Reports by Type</h3>
                <div className="mt-2">
                  <div className="flex items-center">
                    <span className="text-xs text-muted-foreground w-32">Security Assessment</span>
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: `${(reports.filter(r => r.type === 'security-assessment').length / reports.length) * 100}%` }}></div>
                    </div>
                    <span className="ml-2 text-xs text-muted-foreground">
                      {reports.filter(r => r.type === 'security-assessment').length}
                    </span>
                  </div>
                  <div className="flex items-center mt-1">
                    <span className="text-xs text-muted-foreground w-32">Vulnerability Scan</span>
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-warning h-2 rounded-full" style={{ width: `${(reports.filter(r => r.type === 'vulnerability-scan').length / reports.length) * 100}%` }}></div>
                    </div>
                    <span className="ml-2 text-xs text-muted-foreground">
                      {reports.filter(r => r.type === 'vulnerability-scan').length}
                    </span>
                  </div>
                  <div className="flex items-center mt-1">
                    <span className="text-xs text-muted-foreground w-32">Penetration Test</span>
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-accent h-2 rounded-full" style={{ width: `${(reports.filter(r => r.type === 'penetration-test').length / reports.length) * 100}%` }}></div>
                    </div>
                    <span className="ml-2 text-xs text-muted-foreground">
                      {reports.filter(r => r.type === 'penetration-test').length}
                    </span>
                  </div>
                  <div className="flex items-center mt-1">
                    <span className="text-xs text-muted-foreground w-32">Compliance Audit</span>
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-secondary h-2 rounded-full" style={{ width: `${(reports.filter(r => r.type === 'compliance-audit').length / reports.length) * 100}%` }}></div>
                    </div>
                    <span className="ml-2 text-xs text-muted-foreground">
                      {reports.filter(r => r.type === 'compliance-audit').length}
                    </span>
                  </div>
                  <div className="flex items-center mt-1">
                    <span className="text-xs text-muted-foreground w-32">Incident Response</span>
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div className="bg-error h-2 rounded-full" style={{ width: `${(reports.filter(r => r.type === 'incident-response').length / reports.length) * 100}%` }}></div>
                    </div>
                    <span className="ml-2 text-xs text-muted-foreground">
                      {reports.filter(r => r.type === 'incident-response').length}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-border">
                <h3 className="text-sm font-medium text-muted-foreground">Findings Distribution</h3>
                <div className="mt-2 grid grid-cols-3 gap-2">
                  <div className="flex flex-col items-center">
                    <span className="text-xs text-muted-foreground">Critical</span>
                    <div className="rounded-full w-16 h-16 flex items-center justify-center bg-error/20 text-error mt-2">
                      <span className="text-lg font-bold">7</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-center">
                    <span className="text-xs text-muted-foreground">High</span>
                    <div className="rounded-full w-16 h-16 flex items-center justify-center bg-accent/20 text-accent mt-2">
                      <span className="text-lg font-bold">12</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-center">
                    <span className="text-xs text-muted-foreground">Medium</span>
                    <div className="rounded-full w-16 h-16 flex items-center justify-center bg-warning/20 text-warning mt-2">
                      <span className="text-lg font-bold">26</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;