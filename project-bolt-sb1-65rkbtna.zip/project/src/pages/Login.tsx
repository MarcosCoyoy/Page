import React, { useState } from 'react';
import { Shield, Lock, User, ShieldAlert } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading } = useAuth();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      await login(username, password);
    }
  };
  
  return (
    <div className="p-6 bg-card rounded-lg border border-border shadow-lg">
      <div className="flex flex-col items-center justify-center space-y-2 mb-6">
        <ShieldAlert className="h-12 w-12 text-primary mb-2" />
        <h1 className="text-2xl font-bold">PurpleTeamLab</h1>
        <p className="text-center text-muted-foreground">
          Secure training environment for purple team exercises
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <label htmlFor="username" className="text-sm font-medium">
            Username
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
              <User className="h-5 w-5" />
            </div>
            <input
              id="username"
              name="username"
              type="text"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="block w-full rounded-md border-input bg-background py-2 pl-10 pr-3 text-foreground shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary sm:text-sm"
              placeholder="username"
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <label htmlFor="password" className="text-sm font-medium">
            Password
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
              <Lock className="h-5 w-5" />
            </div>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="block w-full rounded-md border-input bg-background py-2 pl-10 pr-3 text-foreground shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary sm:text-sm"
              placeholder="••••••••"
            />
          </div>
        </div>
        
        <div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <Shield className="h-5 w-5 animate-spin" />
            ) : (
              'Sign in'
            )}
          </button>
        </div>
      </form>
      
      <div className="mt-6">
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-card text-muted-foreground">
              Demo accounts
            </span>
          </div>
        </div>
        
        <div className="mt-6 grid grid-cols-2 gap-3 text-xs">
          <div className="rounded-md border border-border p-2">
            <p className="font-medium">Admin</p>
            <p className="text-muted-foreground">Username: admin</p>
            <p className="text-muted-foreground">Password: password</p>
          </div>
          <div className="rounded-md border border-border p-2">
            <p className="font-medium">Red Team</p>
            <p className="text-muted-foreground">Username: red</p>
            <p className="text-muted-foreground">Password: password</p>
          </div>
          <div className="rounded-md border border-border p-2">
            <p className="font-medium">Blue Team</p>
            <p className="text-muted-foreground">Username: blue</p>
            <p className="text-muted-foreground">Password: password</p>
          </div>
          <div className="rounded-md border border-border p-2">
            <p className="font-medium">Purple Team</p>
            <p className="text-muted-foreground">Username: purple</p>
            <p className="text-muted-foreground">Password: password</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;