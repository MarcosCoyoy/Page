import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  AlertTriangle, 
  BarChart, 
  Eye, 
  History, 
  Activity, 
  Play, 
  Square, 
  Check,
  X
} from 'lucide-react';

interface Alert {
  id: string;
  timestamp: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  source: string;
  description: string;
  status: 'new' | 'investigating' | 'resolved' | 'false-positive';
}

interface DefenseTool {
  id: string;
  name: string;
  type: 'detection' | 'prevention' | 'analysis';
  status: 'active' | 'inactive';
  description: string;
}

const BlueTeam: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [defenseTools, setDefenseTools] = useState<DefenseTool[]>([
    {
      id: 'ids',
      name: 'Intrusion Detection System',
      type: 'detection',
      status: 'active',
      description: 'Snort-based network IDS monitoring all traffic',
    },
    {
      id: 'waf',
      name: 'Web Application Firewall',
      type: 'prevention',
      status: 'active',
      description: 'ModSecurity WAF protecting web applications',
    },
    {
      id: 'siem',
      name: 'SIEM System',
      type: 'analysis',
      status: 'active',
      description: 'Centralized log collection and analysis',
    },
    {
      id: 'edr',
      name: 'Endpoint Detection & Response',
      type: 'detection',
      status: 'active',
      description: 'Host-based monitoring and threat detection',
    },
    {
      id: 'honeypot',
      name: 'Honeypot System',
      type: 'detection',
      status: 'inactive',
      description: 'Decoy system to detect and analyze attacks',
    },
  ]);
  
  // Initial alerts
  useEffect(() => {
    const initialAlerts: Alert[] = [
      {
        id: 'alert1',
        timestamp: '2025-04-10 15:32:45',
        severity: 'high',
        source: 'IDS',
        description: 'Multiple port scan attempts detected from IP 192.168.1.105',
        status: 'new',
      },
      {
        id: 'alert2',
        timestamp: '2025-04-10 14:58:12',
        severity: 'critical',
        source: 'WAF',
        description: 'SQL Injection attempt detected on /login.php endpoint',
        status: 'investigating',
      },
      {
        id: 'alert3',
        timestamp: '2025-04-10 13:45:37',
        severity: 'medium',
        source: 'EDR',
        description: 'Suspicious process spawned with elevated privileges on web-server-01',
        status: 'new',
      },
      {
        id: 'alert4',
        timestamp: '2025-04-10 12:22:18',
        severity: 'low',
        source: 'SIEM',
        description: 'Multiple failed login attempts for user "admin"',
        status: 'resolved',
      },
      {
        id: 'alert5',
        timestamp: '2025-04-10 11:15:02',
        severity: 'medium',
        source: 'IDS',
        description: 'Unusual outbound connection to IP 203.0.113.100 on port 4444',
        status: 'false-positive',
      },
    ];
    
    setAlerts(initialAlerts);
  }, []);
  
  const getAlertSeverityClasses = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-error/20 text-error border-error/30';
      case 'high':
        return 'bg-accent/20 text-accent border-accent/30';
      case 'medium':
        return 'bg-warning/20 text-warning border-warning/30';
      case 'low':
        return 'bg-secondary/20 text-secondary border-secondary/30';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };
  
  const getAlertStatusClasses = (status: string) => {
    switch (status) {
      case 'new':
        return 'bg-error/20 text-error';
      case 'investigating':
        return 'bg-warning/20 text-warning';
      case 'resolved':
        return 'bg-success/20 text-success';
      case 'false-positive':
        return 'bg-muted/50 text-muted-foreground';
      default:
        return 'bg-muted/50 text-muted-foreground';
    }
  };
  
  const simulateAttack = () => {
    setIsSimulating(true);
    
    // Simulate a delayed response
    setTimeout(() => {
      const newAlert: Alert = {
        id: `alert${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').substr(0, 19),
        severity: 'critical',
        source: 'IDS',
        description: 'Brute force SSH attack detected from IP 192.168.1.105',
        status: 'new',
      };
      
      setAlerts((prev) => [newAlert, ...prev]);
      setSelectedAlert(newAlert);
      setIsSimulating(false);
    }, 3000);
  };
  
  const toggleToolStatus = (toolId: string) => {
    setDefenseTools((prev) =>
      prev.map((tool) =>
        tool.id === toolId
          ? { ...tool, status: tool.status === 'active' ? 'inactive' : 'active' }
          : tool
      )
    );
  };
  
  const updateAlertStatus = (alertId: string, status: Alert['status']) => {
    setAlerts((prev) =>
      prev.map((alert) =>
        alert.id === alertId ? { ...alert, status } : alert
      )
    );
    
    if (selectedAlert && selectedAlert.id === alertId) {
      setSelectedAlert({ ...selectedAlert, status });
    }
  };
  
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Blue Team Operations</h1>
        <p className="text-muted-foreground">
          Monitor, detect, and respond to security threats
        </p>
      </div>
      
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border border-border bg-card p-6 flex flex-col justify-between">
          <div>
            <div className="rounded-full w-12 h-12 flex items-center justify-center bg-error/20 text-error mb-4">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <h2 className="text-2xl font-bold">{alerts.filter(a => a.status === 'new').length}</h2>
            <p className="text-muted-foreground">New Alerts</p>
          </div>
          <div className={`mt-4 text-xs ${
            alerts.filter(a => a.status === 'new').length > 0 ? 'text-error' : 'text-success'
          }`}>
            {alerts.filter(a => a.status === 'new').length > 0 ? 'Requires attention' : 'All clear'}
          </div>
        </div>
        
        <div className="rounded-lg border border-border bg-card p-6 flex flex-col justify-between">
          <div>
            <div className="rounded-full w-12 h-12 flex items-center justify-center bg-warning/20 text-warning mb-4">
              <History className="h-6 w-6" />
            </div>
            <h2 className="text-2xl font-bold">{alerts.filter(a => a.status === 'investigating').length}</h2>
            <p className="text-muted-foreground">In Investigation</p>
          </div>
          <div className="mt-4 text-xs text-warning">
            In progress
          </div>
        </div>
        
        <div className="rounded-lg border border-border bg-card p-6 flex flex-col justify-between">
          <div>
            <div className="rounded-full w-12 h-12 flex items-center justify-center bg-success/20 text-success mb-4">
              <Check className="h-6 w-6" />
            </div>
            <h2 className="text-2xl font-bold">{alerts.filter(a => a.status === 'resolved').length}</h2>
            <p className="text-muted-foreground">Resolved</p>
          </div>
          <div className="mt-4 text-xs text-success">
            Cases closed
          </div>
        </div>
        
        <div className="rounded-lg border border-border bg-card p-6 flex flex-col justify-between">
          <div>
            <div className="rounded-full w-12 h-12 flex items-center justify-center bg-muted text-muted-foreground mb-4">
              <X className="h-6 w-6" />
            </div>
            <h2 className="text-2xl font-bold">{alerts.filter(a => a.status === 'false-positive').length}</h2>
            <p className="text-muted-foreground">False Positives</p>
          </div>
          <div className="mt-4 text-xs text-muted-foreground">
            No action needed
          </div>
        </div>
      </div>
      
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-lg border border-border bg-card">
            <div className="p-6 border-b border-border flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-warning" />
                  Security Alerts
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Monitor and respond to security incidents
                </p>
              </div>
              <button
                className="inline-flex items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-accent hover:bg-accent/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent/50 disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={simulateAttack}
                disabled={isSimulating}
              >
                {isSimulating ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Simulating...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Simulate Attack
                  </>
                )}
              </button>
            </div>
            
            <div className="divide-y divide-border">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-4 flex cursor-pointer transition-colors hover:bg-muted/50 ${
                    selectedAlert?.id === alert.id ? 'bg-muted' : ''
                  }`}
                  onClick={() => setSelectedAlert(alert)}
                >
                  <div
                    className={`flex-shrink-0 h-4 w-4 rounded-full mt-1 ${
                      alert.severity === 'critical'
                        ? 'bg-error'
                        : alert.severity === 'high'
                        ? 'bg-accent'
                        : alert.severity === 'medium'
                        ? 'bg-warning'
                        : 'bg-secondary'
                    } ${alert.status === 'new' ? 'animate-pulse' : ''}`}
                  />
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">
                        {alert.description}
                      </p>
                      <div className="ml-2 flex-shrink-0">
                        <p
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getAlertStatusClasses(
                            alert.status
                          )}`}
                        >
                          {alert.status.replace('-', ' ')}
                        </p>
                      </div>
                    </div>
                    <div className="mt-1 flex items-center text-xs text-muted-foreground">
                      <p>
                        {alert.timestamp} • 
                        <span className="ml-1 font-medium">{alert.source}</span>
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              
              {alerts.length === 0 && (
                <div className="p-6 text-center text-muted-foreground">
                  No alerts found
                </div>
              )}
            </div>
          </div>
          
          {selectedAlert && (
            <div className="rounded-lg border border-border bg-card p-6">
              <h2 className="text-xl font-semibold mb-4">Alert Details</h2>
              
              <div className={`p-4 rounded-md border ${getAlertSeverityClasses(selectedAlert.severity)}`}>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium">{selectedAlert.description}</h3>
                    <p className="text-sm mt-1">
                      Detected at {selectedAlert.timestamp} by {selectedAlert.source}
                    </p>
                  </div>
                  <span
                    className={`px-2 py-1 rounded-md text-xs font-semibold uppercase ${
                      selectedAlert.severity === 'critical'
                        ? 'bg-error/30 text-error'
                        : selectedAlert.severity === 'high'
                        ? 'bg-accent/30 text-accent'
                        : selectedAlert.severity === 'medium'
                        ? 'bg-warning/30 text-warning'
                        : 'bg-secondary/30 text-secondary'
                    }`}
                  >
                    {selectedAlert.severity}
                  </span>
                </div>
              </div>
              
              <div className="mt-6 space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Recommended Actions</h3>
                  <ul className="mt-2 text-sm space-y-2">
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-success mr-2" />
                      Investigate source IP for suspicious behavior
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-success mr-2" />
                      Review logs for additional indicators of compromise
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-success mr-2" />
                      Verify system integrity and patch status
                    </li>
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-success mr-2" />
                      Update firewall rules if needed
                    </li>
                  </ul>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <h3 className="text-sm font-medium text-muted-foreground">Update Alert Status</h3>
                  <div className="mt-2 flex space-x-2">
                    <button
                      className={`px-3 py-1 text-xs rounded-md border ${
                        selectedAlert.status === 'investigating'
                          ? 'bg-warning/20 text-warning border-warning/30'
                          : 'border-border hover:bg-muted'
                      }`}
                      onClick={() => updateAlertStatus(selectedAlert.id, 'investigating')}
                    >
                      Investigating
                    </button>
                    <button
                      className={`px-3 py-1 text-xs rounded-md border ${
                        selectedAlert.status === 'resolved'
                          ? 'bg-success/20 text-success border-success/30'
                          : 'border-border hover:bg-muted'
                      }`}
                      onClick={() => updateAlertStatus(selectedAlert.id, 'resolved')}
                    >
                      Resolved
                    </button>
                    <button
                      className={`px-3 py-1 text-xs rounded-md border ${
                        selectedAlert.status === 'false-positive'
                          ? 'bg-muted/50 text-muted-foreground border-muted-foreground/30'
                          : 'border-border hover:bg-muted'
                      }`}
                      onClick={() => updateAlertStatus(selectedAlert.id, 'false-positive')}
                    >
                      False Positive
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="space-y-6">
          <div className="rounded-lg border border-border bg-card">
            <div className="p-6">
              <h2 className="text-xl font-semibold flex items-center">
                <Shield className="h-5 w-5 mr-2 text-secondary" />
                Defense Tools
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Manage security controls
              </p>
            </div>
            
            <div className="border-t border-border">
              {defenseTools.map((tool) => (
                <div
                  key={tool.id}
                  className="p-4 border-b border-border last:border-0"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium flex items-center">
                        {tool.name}
                        <span
                          className={`ml-2 px-2 py-0.5 text-xs rounded-full ${
                            tool.status === 'active'
                              ? 'bg-success/10 text-success'
                              : 'bg-error/10 text-error'
                          }`}
                        >
                          {tool.status}
                        </span>
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {tool.description}
                      </p>
                      <div className="mt-2">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-foreground">
                          {tool.type}
                        </span>
                      </div>
                    </div>
                    <button
                      className={`ml-4 relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none ${
                        tool.status === 'active'
                          ? 'bg-success'
                          : 'bg-muted'
                      }`}
                      onClick={() => toggleToolStatus(tool.id)}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200 ${
                          tool.status === 'active'
                            ? 'translate-x-5'
                            : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="rounded-lg border border-border bg-card p-6">
            <h2 className="text-xl font-semibold flex items-center mb-4">
              <BarChart className="h-5 w-5 mr-2 text-primary" />
              Security Metrics
            </h2>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium">Threat Detection Rate</span>
                  <span className="text-sm font-medium text-success">87%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-success h-2 rounded-full" style={{ width: '87%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium">Mean Time to Detect</span>
                  <span className="text-sm font-medium text-secondary">2.4h</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-secondary h-2 rounded-full" style={{ width: '68%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium">Mean Time to Respond</span>
                  <span className="text-sm font-medium text-warning">3.8h</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-warning h-2 rounded-full" style={{ width: '45%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium">False Positive Rate</span>
                  <span className="text-sm font-medium text-accent">12%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-accent h-2 rounded-full" style={{ width: '12%' }}></div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-border">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">System Health</h3>
              <div className="flex items-center">
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-success"></div>
                  <span className="ml-1.5 text-xs text-muted-foreground">IDS</span>
                </div>
                <div className="flex items-center ml-4">
                  <div className="h-3 w-3 rounded-full bg-success"></div>
                  <span className="ml-1.5 text-xs text-muted-foreground">WAF</span>
                </div>
                <div className="flex items-center ml-4">
                  <div className="h-3 w-3 rounded-full bg-success"></div>
                  <span className="ml-1.5 text-xs text-muted-foreground">SIEM</span>
                </div>
                <div className="flex items-center ml-4">
                  <div className="h-3 w-3 rounded-full bg-warning"></div>
                  <span className="ml-1.5 text-xs text-muted-foreground">EDR</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlueTeam;