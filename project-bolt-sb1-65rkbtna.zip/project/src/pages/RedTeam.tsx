import React, { useState } from 'react';
import { Target, Play, AlertTriangle, Eye, Shield, Check, X } from 'lucide-react';

interface Tool {
  id: string;
  name: string;
  description: string;
  category: 'reconnaissance' | 'exploitation' | 'persistence' | 'privilege-escalation';
  command: string;
}

interface Target {
  id: string;
  name: string;
  ip: string;
  os: string;
  services: {
    port: number;
    name: string;
    version: string;
    vulnerabilities?: number;
  }[];
  vulnerabilities: number;
  status: 'online' | 'offline';
}

const RedTeam: React.FC = () => {
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);
  const [selectedTarget, setSelectedTarget] = useState<Target | null>(null);
  const [terminalOutput, setTerminalOutput] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  
  const tools: Tool[] = [
    {
      id: 'nmap',
      name: 'Nmap',
      description: 'Network discovery and security auditing',
      category: 'reconnaissance',
      command: 'nmap -sV -p- TARGET_IP',
    },
    {
      id: 'sqlmap',
      name: 'SQLMap',
      description: 'Automatic SQL injection detection and exploitation',
      category: 'exploitation',
      command: 'sqlmap -u "http://TARGET_IP/page.php?id=1" --dbs',
    },
    {
      id: 'metasploit',
      name: 'Metasploit',
      description: 'Penetration testing framework',
      category: 'exploitation',
      command: 'msfconsole -q -x "use exploit/multi/http/TARGET_EXPLOIT; set RHOSTS TARGET_IP; exploit"',
    },
    {
      id: 'hydra',
      name: 'Hydra',
      description: 'Brute force online password cracking',
      category: 'exploitation',
      command: 'hydra -l admin -P /usr/share/wordlists/rockyou.txt TARGET_IP ssh',
    },
    {
      id: 'reverse-shell',
      name: 'Reverse Shell',
      description: 'Establish a reverse shell connection',
      category: 'persistence',
      command: 'nc -lvp 4444',
    },
    {
      id: 'linpeas',
      name: 'LinPEAS',
      description: 'Linux Privilege Escalation Awesome Script',
      category: 'privilege-escalation',
      command: './linpeas.sh',
    },
  ];
  
  const targets: Target[] = [
    {
      id: 'target1',
      name: 'Web Server',
      ip: '192.168.1.100',
      os: 'Ubuntu 22.04 LTS',
      services: [
        { port: 22, name: 'SSH', version: 'OpenSSH 8.9p1' },
        { port: 80, name: 'HTTP', version: 'Apache 2.4.52', vulnerabilities: 2 },
        { port: 443, name: 'HTTPS', version: 'Apache 2.4.52', vulnerabilities: 1 },
        { port: 3306, name: 'MySQL', version: '8.0.28', vulnerabilities: 1 }
      ],
      vulnerabilities: 4,
      status: 'online',
    },
    {
      id: 'target2',
      name: 'File Server',
      ip: '192.168.1.101',
      os: 'Debian 12',
      services: [
        { port: 22, name: 'SSH', version: 'OpenSSH 9.2p1' },
        { port: 21, name: 'FTP', version: 'vsftpd 3.0.3', vulnerabilities: 1 },
        { port: 445, name: 'SMB', version: 'Samba 4.17.7', vulnerabilities: 2 }
      ],
      vulnerabilities: 3,
      status: 'online',
    },
    {
      id: 'target3',
      name: 'Windows Domain Controller',
      ip: '192.168.1.102',
      os: 'Windows Server 2022',
      services: [
        { port: 3389, name: 'RDP', version: 'Windows Remote Desktop' },
        { port: 445, name: 'SMB', version: 'Microsoft Windows SMB', vulnerabilities: 2 },
        { port: 88, name: 'Kerberos', version: 'Windows Kerberos' },
        { port: 389, name: 'LDAP', version: 'Microsoft LDAP', vulnerabilities: 1 }
      ],
      vulnerabilities: 3,
      status: 'online',
    },
  ];
  
  const runTool = () => {
    if (!selectedTool || !selectedTarget) return;
    
    setIsRunning(true);
    setTerminalOutput([
      `[*] Running ${selectedTool.name} against ${selectedTarget.name} (${selectedTarget.ip})`,
      `[*] Command: ${selectedTool.command.replace('TARGET_IP', selectedTarget.ip)}`,
      '[*] Starting execution...',
    ]);
    
    // Simulate command execution with setTimeout
    setTimeout(() => {
      let output: string[] = [];
      
      // Generate fake output based on the tool
      if (selectedTool.id === 'nmap') {
        output = [
          'Starting Nmap 7.93 ( https://nmap.org )',
          `Nmap scan report for ${selectedTarget.ip}`,
          'Host is up (0.0045s latency).',
          'Not shown: 997 closed ports',
          'PORT    STATE SERVICE  VERSION',
          ...selectedTarget.services.map(service => 
            `${service.port}/tcp open  ${service.name.toLowerCase().padEnd(8)} ${service.version}`
          ),
          'Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .',
          'Nmap done: 1 IP address (1 host up) scanned in 22.05 seconds',
        ];
      } else if (selectedTool.id === 'sqlmap') {
        if (selectedTarget.services.some(s => s.name === 'HTTP' || s.name === 'HTTPS')) {
          output = [
            'sqlmap identified the following injection point(s) with a total of 46 HTTP(s) requests:',
            '---',
            'Parameter: id (GET)',
            '    Type: boolean-based blind',
            '    Title: AND boolean-based blind - WHERE or HAVING clause',
            '    Payload: id=1 AND 5834=5834',
            '',
            '    Type: time-based blind',
            '    Title: MySQL >= 5.0.12 AND time-based blind (query SLEEP)',
            '    Payload: id=1 AND (SELECT 3669 FROM (SELECT(SLEEP(5)))TmcS)',
            '---',
            'available databases [5]:',
            '[*] information_schema',
            '[*] mysql',
            '[*] performance_schema',
            '[*] sys',
            '[*] webapp_db',
          ];
        } else {
          output = [
            '[!] No HTTP service found on target.',
            '[!] Stopping the attack.',
          ];
        }
      } else if (selectedTool.id === 'hydra') {
        output = [
          'Hydra v9.4 (c) 2022 by van Hauser/THC & David Maciejak - Please do not use in military or secret service organizations, or for illegal purposes.',
          '',
          'Hydra (https://github.com/vanhauser-thc/thc-hydra) starting at 2025-04-10 16:32:11',
          '[DATA] max 16 tasks per 1 server, overall 16 tasks, 14344399 login tries (l:1/p:14344399), ~896525 tries per task',
          '[DATA] attacking ssh://192.168.1.100:22/',
          '[STATUS] 176.00 tries/min, 176 tries in 00:01h, 14344223 to do in 1358:30h, 16 active',
          '[STATUS] 183.67 tries/min, 551 tries in 00:03h, 14343848 to do in 1301:39h, 16 active',
          '[22][ssh] host: 192.168.1.100   login: admin   password: admin123',
          '[STATUS] attack finished for 192.168.1.100 (waiting for children to complete tests)',
          '1 of 1 target successfully completed, 1 valid password found',
        ];
      } else {
        output = [
          '[*] Executing command...',
          '[*] Operation completed successfully.',
          '[*] Check the results for detailed information.',
        ];
      }
      
      // Add Blue Team detection chance
      if (Math.random() > 0.5) {
        output.push('');
        output.push('[!] ALERT: Activity potentially detected by Blue Team monitoring!');
        output.push('[!] Consider modifying your approach to be more stealthy.');
      }
      
      setTerminalOutput(prev => [...prev, ...output]);
      setIsRunning(false);
    }, 3000);
  };
  
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Red Team Operations</h1>
        <p className="text-muted-foreground">
          Conduct offensive security operations and penetration testing
        </p>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-6">
          <div className="rounded-lg border border-border bg-card">
            <div className="p-6">
              <h2 className="text-xl font-semibold flex items-center">
                <Target className="h-5 w-5 mr-2 text-accent" />
                Target Systems
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Select a target system to attack
              </p>
            </div>
            <div className="border-t border-border">
              {targets.map((target) => (
                <div
                  key={target.id}
                  className={`p-4 border-b border-border flex justify-between items-center transition-colors hover:bg-muted/50 cursor-pointer ${
                    selectedTarget?.id === target.id ? 'bg-muted' : ''
                  }`}
                  onClick={() => setSelectedTarget(target)}
                >
                  <div>
                    <div className="flex items-center">
                      <span className="font-medium">{target.name}</span>
                      <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                        target.status === 'online' ? 'bg-success/20 text-success' : 'bg-error/20 text-error'
                      }`}>
                        {target.status}
                      </span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {target.ip} • {target.os}
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <AlertTriangle className="h-4 w-4 text-warning mr-1" />
                      <span className="text-sm">{target.vulnerabilities}</span>
                    </div>
                    <Eye className="h-5 w-5 text-muted-foreground" />
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {selectedTarget && (
            <div className="rounded-lg border border-border bg-card">
              <div className="p-6">
                <h2 className="text-xl font-semibold">{selectedTarget.name}</h2>
                <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">IP Address:</span>{' '}
                    <span className="font-mono">{selectedTarget.ip}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">OS:</span>{' '}
                    <span>{selectedTarget.os}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Status:</span>{' '}
                    <span className={`${
                      selectedTarget.status === 'online' ? 'text-success' : 'text-error'
                    }`}>
                      {selectedTarget.status.toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Vulnerabilities:</span>{' '}
                    <span className={`${
                      selectedTarget.vulnerabilities > 0 ? 'text-warning' : 'text-success'
                    }`}>
                      {selectedTarget.vulnerabilities}
                    </span>
                  </div>
                </div>
                
                <h3 className="text-lg font-medium mt-4">Open Ports & Services</h3>
                <div className="mt-2 border rounded-md overflow-hidden">
                  <table className="min-w-full">
                    <thead>
                      <tr className="bg-muted/50">
                        <th className="py-2 px-3 text-left text-sm font-medium text-muted-foreground">Port</th>
                        <th className="py-2 px-3 text-left text-sm font-medium text-muted-foreground">Service</th>
                        <th className="py-2 px-3 text-left text-sm font-medium text-muted-foreground">Version</th>
                        <th className="py-2 px-3 text-left text-sm font-medium text-muted-foreground">Vulns</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedTarget.services.map((service, index) => (
                        <tr key={index} className="border-t border-border">
                          <td className="py-2 px-3 text-sm font-mono">{service.port}</td>
                          <td className="py-2 px-3 text-sm">{service.name}</td>
                          <td className="py-2 px-3 text-sm">{service.version}</td>
                          <td className="py-2 px-3">
                            {service.vulnerabilities ? (
                              <span className="inline-flex items-center text-xs text-warning">
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                {service.vulnerabilities}
                              </span>
                            ) : (
                              <span className="inline-flex items-center text-xs text-success">
                                <Shield className="h-3 w-3 mr-1" />
                                Secure
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="space-y-6">
          <div className="rounded-lg border border-border bg-card">
            <div className="p-6">
              <h2 className="text-xl font-semibold flex items-center">
                <Target className="h-5 w-5 mr-2 text-accent" />
                Attack Tools
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Select a tool to use against the target
              </p>
              
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {tools.map((tool) => (
                  <div
                    key={tool.id}
                    className={`border border-border rounded-lg p-3 cursor-pointer transition-colors hover:bg-muted/50 ${
                      selectedTool?.id === tool.id ? 'bg-muted border-primary' : ''
                    }`}
                    onClick={() => setSelectedTool(tool)}
                  >
                    <div className="font-medium">{tool.name}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {tool.description}
                    </div>
                    <div className="mt-2">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-foreground">
                        {tool.category}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="p-6 border-t border-border flex">
              <button
                className="flex-1 inline-flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-accent hover:bg-accent/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent/50 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!selectedTool || !selectedTarget || isRunning}
                onClick={runTool}
              >
                {isRunning ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Running...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Run Tool
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="rounded-lg border border-border bg-card p-6">
            <h2 className="text-xl font-semibold mb-4">Terminal Output</h2>
            <div className="terminal h-[400px] overflow-auto text-sm">
              {terminalOutput.length > 0 ? (
                terminalOutput.map((line, i) => (
                  <div key={i} className={
                    line.startsWith('[+]') ? 'terminal-success' :
                    line.startsWith('[!]') ? 'terminal-error' :
                    line.startsWith('[*]') ? 'terminal-warning' : ''
                  }>
                    {line}
                  </div>
                ))
              ) : (
                <div className="text-muted-foreground">
                  Select a target and tool, then click "Run Tool" to begin...
                </div>
              )}
              {isRunning && <div className="terminal-input animate-pulse">_</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RedTeam;