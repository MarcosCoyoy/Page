import React, { useState } from 'react';
import { 
  Settings as SettingsIcon,
  Shield, 
  Lock, 
  Bell, 
  Key,
  Server,
  Network,
  Fingerprint,
  File,
  CheckCircle2,
  Save,
  LogOut
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Settings: React.FC = () => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('general');
  
  const [generalSettings, setGeneralSettings] = useState({
    labName: 'PurpleTeam Security Lab',
    maxSessionTime: '4',
    autoLogout: true,
    showTips: true,
  });
  
  const [securitySettings, setSecuritySettings] = useState({
    requireMFA: true,
    passwordExpiration: '90',
    passwordComplexity: 'high',
    sessionTimeout: '30',
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailAlerts: true,
    slackAlerts: false,
    alertOnLogin: true,
    alertOnVulnerability: true,
    alertOnScan: false,
  });
  
  const handleGeneralChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setGeneralSettings({
      ...generalSettings,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    });
  };
  
  const handleSecurityChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setSecuritySettings({
      ...securitySettings,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    });
  };
  
  const handleNotificationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setNotificationSettings({
      ...notificationSettings,
      [name]: checked,
    });
  };
  
  if (user?.role !== 'admin') {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center">
        <Shield className="h-16 w-16 text-muted-foreground mb-6" />
        <h1 className="text-2xl font-bold mb-2">Access Restricted</h1>
        <p className="text-muted-foreground text-center max-w-md">
          You don't have permission to access settings. Please contact an administrator.
        </p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">
          Configure your purple team environment
        </p>
      </div>
      
      <div className="grid gap-6 md:grid-cols-4">
        <div className="space-y-4">
          <div className="rounded-lg border border-border bg-card overflow-hidden">
            <div className="p-4 border-b border-border">
              <h2 className="font-semibold">Settings Menu</h2>
            </div>
            <nav className="p-2">
              <button
                className={`w-full flex items-center p-2 text-sm rounded-md ${
                  activeTab === 'general' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setActiveTab('general')}
              >
                <SettingsIcon className="h-4 w-4 mr-2" />
                General
              </button>
              <button
                className={`w-full flex items-center p-2 text-sm rounded-md ${
                  activeTab === 'security' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setActiveTab('security')}
              >
                <Shield className="h-4 w-4 mr-2" />
                Security
              </button>
              <button
                className={`w-full flex items-center p-2 text-sm rounded-md ${
                  activeTab === 'notifications' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setActiveTab('notifications')}
              >
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </button>
              <button
                className={`w-full flex items-center p-2 text-sm rounded-md ${
                  activeTab === 'certificates' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setActiveTab('certificates')}
              >
                <Key className="h-4 w-4 mr-2" />
                Certificates
              </button>
              <button
                className={`w-full flex items-center p-2 text-sm rounded-md ${
                  activeTab === 'infrastructure' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setActiveTab('infrastructure')}
              >
                <Server className="h-4 w-4 mr-2" />
                Infrastructure
              </button>
              <button
                className={`w-full flex items-center p-2 text-sm rounded-md ${
                  activeTab === 'integrations' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setActiveTab('integrations')}
              >
                <Network className="h-4 w-4 mr-2" />
                Integrations
              </button>
              <button
                className={`w-full flex items-center p-2 text-sm rounded-md ${
                  activeTab === 'authentication' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setActiveTab('authentication')}
              >
                <Fingerprint className="h-4 w-4 mr-2" />
                Authentication
              </button>
              <button
                className={`w-full flex items-center p-2 text-sm rounded-md ${
                  activeTab === 'logs' ? 'bg-primary/10 text-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setActiveTab('logs')}
              >
                <File className="h-4 w-4 mr-2" />
                Logs
              </button>
            </nav>
          </div>
          
          <div className="rounded-lg border border-border bg-card p-4">
            <button
              className="w-full flex items-center justify-center p-2 text-sm rounded-md bg-error/10 text-error hover:bg-error/20"
              onClick={logout}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </button>
          </div>
        </div>
        
        <div className="md:col-span-3">
          {activeTab === 'general' && (
            <div className="rounded-lg border border-border bg-card overflow-hidden">
              <div className="p-6 border-b border-border">
                <h2 className="text-xl font-semibold flex items-center">
                  <SettingsIcon className="h-5 w-5 mr-2 text-primary" />
                  General Settings
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Configure basic lab environment settings
                </p>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="grid gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label htmlFor="labName" className="block text-sm font-medium">
                      Lab Name
                    </label>
                    <input
                      type="text"
                      id="labName"
                      name="labName"
                      value={generalSettings.labName}
                      onChange={handleGeneralChange}
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="maxSessionTime" className="block text-sm font-medium">
                      Max Session Time (hours)
                    </label>
                    <select
                      id="maxSessionTime"
                      name="maxSessionTime"
                      value={generalSettings.maxSessionTime}
                      onChange={handleGeneralChange}
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    >
                      <option value="1">1 hour</option>
                      <option value="2">2 hours</option>
                      <option value="4">4 hours</option>
                      <option value="8">8 hours</option>
                      <option value="12">12 hours</option>
                    </select>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="autoLogout"
                      name="autoLogout"
                      checked={generalSettings.autoLogout}
                      onChange={handleGeneralChange}
                      className="rounded border-input text-primary focus:ring-primary/50"
                    />
                    <label htmlFor="autoLogout" className="ml-2 block text-sm">
                      Auto logout on session expiration
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="showTips"
                      name="showTips"
                      checked={generalSettings.showTips}
                      onChange={handleGeneralChange}
                      className="rounded border-input text-primary focus:ring-primary/50"
                    />
                    <label htmlFor="showTips" className="ml-2 block text-sm">
                      Show tooltips and guidance
                    </label>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <button
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'security' && (
            <div className="rounded-lg border border-border bg-card overflow-hidden">
              <div className="p-6 border-b border-border">
                <h2 className="text-xl font-semibold flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-primary" />
                  Security Settings
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Configure security options for the lab environment
                </p>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="grid gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label htmlFor="passwordComplexity" className="block text-sm font-medium">
                      Password Complexity
                    </label>
                    <select
                      id="passwordComplexity"
                      name="passwordComplexity"
                      value={securitySettings.passwordComplexity}
                      onChange={handleSecurityChange}
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    >
                      <option value="low">Low (8+ characters)</option>
                      <option value="medium">Medium (8+ chars, mixed case, numbers)</option>
                      <option value="high">High (12+ chars, mixed case, numbers, symbols)</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="passwordExpiration" className="block text-sm font-medium">
                      Password Expiration (days)
                    </label>
                    <select
                      id="passwordExpiration"
                      name="passwordExpiration"
                      value={securitySettings.passwordExpiration}
                      onChange={handleSecurityChange}
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    >
                      <option value="30">30 days</option>
                      <option value="60">60 days</option>
                      <option value="90">90 days</option>
                      <option value="180">180 days</option>
                      <option value="never">Never</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="sessionTimeout" className="block text-sm font-medium">
                      Session Timeout (minutes)
                    </label>
                    <select
                      id="sessionTimeout"
                      name="sessionTimeout"
                      value={securitySettings.sessionTimeout}
                      onChange={handleSecurityChange}
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    >
                      <option value="15">15 minutes</option>
                      <option value="30">30 minutes</option>
                      <option value="60">60 minutes</option>
                      <option value="120">120 minutes</option>
                    </select>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="requireMFA"
                      name="requireMFA"
                      checked={securitySettings.requireMFA}
                      onChange={handleSecurityChange}
                      className="rounded border-input text-primary focus:ring-primary/50"
                    />
                    <label htmlFor="requireMFA" className="ml-2 block text-sm">
                      Require multi-factor authentication
                    </label>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <button
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'notifications' && (
            <div className="rounded-lg border border-border bg-card overflow-hidden">
              <div className="p-6 border-b border-border">
                <h2 className="text-xl font-semibold flex items-center">
                  <Bell className="h-5 w-5 mr-2 text-primary" />
                  Notification Settings
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Configure alerts and notifications
                </p>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium">Email Alerts</h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        Receive security alerts via email
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        name="emailAlerts"
                        checked={notificationSettings.emailAlerts}
                        onChange={handleNotificationChange}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-muted rounded-full peer peer-focus:ring-4 peer-focus:ring-primary/25 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-muted-foreground after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium">Slack Alerts</h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        Send notifications to Slack channel
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        name="slackAlerts"
                        checked={notificationSettings.slackAlerts}
                        onChange={handleNotificationChange}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-muted rounded-full peer peer-focus:ring-4 peer-focus:ring-primary/25 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-muted-foreground after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>
                  
                  <div className="pt-4 border-t border-border">
                    <h3 className="text-sm font-medium mb-2">Notification Triggers</h3>
                    
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="alertOnLogin"
                          name="alertOnLogin"
                          checked={notificationSettings.alertOnLogin}
                          onChange={handleNotificationChange}
                          className="rounded border-input text-primary focus:ring-primary/50"
                        />
                        <label htmlFor="alertOnLogin" className="ml-2 block text-sm">
                          New login attempts
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="alertOnVulnerability"
                          name="alertOnVulnerability"
                          checked={notificationSettings.alertOnVulnerability}
                          onChange={handleNotificationChange}
                          className="rounded border-input text-primary focus:ring-primary/50"
                        />
                        <label htmlFor="alertOnVulnerability" className="ml-2 block text-sm">
                          New vulnerabilities detected
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="alertOnScan"
                          name="alertOnScan"
                          checked={notificationSettings.alertOnScan}
                          onChange={handleNotificationChange}
                          className="rounded border-input text-primary focus:ring-primary/50"
                        />
                        <label htmlFor="alertOnScan" className="ml-2 block text-sm">
                          Scan completion
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <button
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'certificates' && (
            <div className="rounded-lg border border-border bg-card overflow-hidden">
              <div className="p-6 border-b border-border">
                <h2 className="text-xl font-semibold flex items-center">
                  <Key className="h-5 w-5 mr-2 text-primary" />
                  Certificate Management
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Manage self-signed SSL certificates for your lab environment
                </p>
              </div>
              
              <div className="p-6 space-y-6">
                <div className="rounded-md border border-border bg-muted/50 p-4">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <CheckCircle2 className="h-5 w-5 text-success" />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-sm font-medium">Self-signed certificate is active</h3>
                      <div className="mt-2 text-sm text-muted-foreground">
                        <p>Your lab is currently using a self-signed SSL certificate for HTTPS connections. This certificate will not be trusted by browsers by default.</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="grid gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label className="block text-sm font-medium">
                      Certificate Common Name
                    </label>
                    <input
                      type="text"
                      value="purpleteamlab.local"
                      readOnly
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-medium">
                      Expiration Date
                    </label>
                    <input
                      type="text"
                      value="2026-04-10"
                      readOnly
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    />
                  </div>
                </div>
                
                <div className="grid gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <label className="block text-sm font-medium">
                      Key Size
                    </label>
                    <select
                      defaultValue="2048"
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    >
                      <option value="1024">1024 bits (not recommended)</option>
                      <option value="2048">2048 bits</option>
                      <option value="4096">4096 bits</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-medium">
                      Validity Period
                    </label>
                    <select
                      defaultValue="365"
                      className="w-full rounded-md border-input bg-background py-2 px-3 text-sm shadow-sm focus:ring-2 focus:ring-primary/50 focus:border-primary"
                    >
                      <option value="30">30 days</option>
                      <option value="90">90 days</option>
                      <option value="365">365 days</option>
                      <option value="730">730 days</option>
                    </select>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-2">
                    <button
                      type="button"
                      className="inline-flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                    >
                      <Key className="h-4 w-4 mr-2" />
                      Generate New Certificate
                    </button>
                    
                    <button
                      type="button"
                      className="inline-flex justify-center items-center py-2 px-4 border border-border rounded-md text-sm font-medium text-foreground hover:bg-muted focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary/50"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Certificate
                    </button>
                  </div>
                </div>
                
                <div className="mt-4 text-sm text-muted-foreground">
                  <p>
                    <strong>Note:</strong> Using self-signed certificates is suitable for lab environments, but browsers will display warnings. For production environments, use certificates from a trusted certificate authority.
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {/* Add other settings tabs as needed */}
          
          {(activeTab === 'infrastructure' || activeTab === 'integrations' || 
            activeTab === 'authentication' || activeTab === 'logs') && (
            <div className="rounded-lg border border-border bg-card p-6">
              <div className="flex flex-col items-center justify-center text-center h-64">
                <SettingsIcon className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">Settings Under Construction</h3>
                <p className="text-sm text-muted-foreground mt-2 max-w-md">
                  This settings section is currently being developed and will be available in a future update.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;