import React from 'react';
import { 
  ShieldAlert, 
  Target, 
  Shield, 
  AlertTriangle, 
  Activity, 
  Users 
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ElementType;
  description: string;
  trend?: {
    value: number;
    label: string;
  };
  color: 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'error';
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon: Icon,
  description,
  trend,
  color,
}) => {
  const colorClasses = {
    primary: 'bg-primary/10 text-primary border-primary/20',
    secondary: 'bg-secondary/10 text-secondary border-secondary/20',
    accent: 'bg-accent/10 text-accent border-accent/20',
    success: 'bg-success/10 text-success border-success/20',
    warning: 'bg-warning/10 text-warning border-warning/20',
    error: 'bg-error/10 text-error border-error/20',
  };
  
  return (
    <div className="rounded-lg border border-border bg-card p-6">
      <div className="flex items-center">
        <div className={`rounded-full p-2 ${colorClasses[color]}`}>
          <Icon className="h-6 w-6" />
        </div>
        <div className="ml-4 flex-1">
          <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
          <div className="mt-1 flex items-baseline">
            <p className="text-2xl font-semibold">{value}</p>
            {trend && (
              <p
                className={`ml-2 text-sm ${
                  trend.value >= 0 ? 'text-success' : 'text-error'
                }`}
              >
                {trend.value >= 0 ? '+' : ''}
                {trend.value}% {trend.label}
              </p>
            )}
          </div>
        </div>
      </div>
      <p className="mt-4 text-sm text-muted-foreground">{description}</p>
    </div>
  );
};

interface ActivityItemProps {
  time: string;
  title: string;
  description: string;
  status: 'info' | 'success' | 'warning' | 'error';
}

const ActivityItem: React.FC<ActivityItemProps> = ({
  time,
  title,
  description,
  status,
}) => {
  const statusClasses = {
    info: 'bg-secondary/20 border-secondary/30',
    success: 'bg-success/20 border-success/30',
    warning: 'bg-warning/20 border-warning/30',
    error: 'bg-error/20 border-error/30',
  };
  
  return (
    <div className="flex space-x-4">
      <div className="relative flex-none">
        <div
          className={`absolute top-0 left-0 h-3 w-3 rounded-full ${
            status === 'error' ? 'alert-pulse' : ''
          }`}
          style={{
            backgroundColor:
              status === 'info'
                ? 'var(--secondary)'
                : status === 'success'
                ? 'var(--success)'
                : status === 'warning'
                ? 'var(--warning)'
                : 'var(--error)',
          }}
        />
        <div className="h-full w-px bg-border ml-1.5" />
      </div>
      <div className="flex-1 space-y-1 pb-6">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-semibold">{title}</h4>
          <p className="text-xs text-muted-foreground">{time}</p>
        </div>
        <div className={`p-3 rounded-md text-sm ${statusClasses[status]}`}>
          {description}
        </div>
      </div>
    </div>
  );
};

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  
  const recentActivity = [
    {
      time: '10 minutes ago',
      title: 'Brute Force Detection',
      description:
        'Multiple failed login attempts detected from IP 192.168.1.105',
      status: 'error' as const,
    },
    {
      time: '1 hour ago',
      title: 'SQL Injection Exercise',
      description: 'Exercise completed by blue team with 85% success rate',
      status: 'success' as const,
    },
    {
      time: '3 hours ago',
      title: 'New Vulnerability Detected',
      description: 'CVE-2023-4578 identified in target system',
      status: 'warning' as const,
    },
    {
      time: '5 hours ago',
      title: 'Firewall Rules Updated',
      description: 'Administrator updated 3 firewall rules for target environment',
      status: 'info' as const,
    },
  ];
  
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back, {user?.name}. Here's what's happening in your purple team environment.
        </p>
      </div>
      
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          title="Active Vulnerabilities"
          value={17}
          icon={AlertTriangle}
          description="Vulnerabilities detected across all environments"
          trend={{ value: -4, label: 'from last week' }}
          color="warning"
        />
        <StatCard
          title="Attack Simulations"
          value={8}
          icon={Target}
          description="Red team attack simulations in progress"
          trend={{ value: 2, label: 'from last week' }}
          color="accent"
        />
        <StatCard
          title="Defense Success Rate"
          value="73%"
          icon={Shield}
          description="Blue team detection and mitigation rate"
          trend={{ value: 5, label: 'from last week' }}
          color="secondary"
        />
        <StatCard
          title="Active Team Members"
          value={12}
          icon={Users}
          description="Team members currently participating in exercises"
          color="primary"
        />
        <StatCard
          title="Security Score"
          value="B+"
          icon={ShieldAlert}
          description="Overall security posture rating"
          trend={{ value: 8, label: 'improvement' }}
          color="success"
        />
        <StatCard
          title="System Uptime"
          value="99.8%"
          icon={Activity}
          description="Target environment availability"
          color="secondary"
        />
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
            <div className="rounded-lg border border-border bg-card p-6">
              <div className="space-y-2">
                {recentActivity.map((activity, index) => (
                  <ActivityItem
                    key={index}
                    time={activity.time}
                    title={activity.title}
                    description={activity.description}
                    status={activity.status}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
            <div className="rounded-lg border border-border bg-card p-6">
              <div className="grid gap-4 md:grid-cols-2">
                <button className="flex flex-col items-center justify-center rounded-lg border border-border bg-background p-4 transition-colors hover:bg-muted">
                  <Target className="h-8 w-8 text-accent mb-2" />
                  <span className="text-sm font-medium">Start Attack</span>
                </button>
                <button className="flex flex-col items-center justify-center rounded-lg border border-border bg-background p-4 transition-colors hover:bg-muted">
                  <Shield className="h-8 w-8 text-secondary mb-2" />
                  <span className="text-sm font-medium">Deploy Defense</span>
                </button>
                <button className="flex flex-col items-center justify-center rounded-lg border border-border bg-background p-4 transition-colors hover:bg-muted">
                  <AlertTriangle className="h-8 w-8 text-warning mb-2" />
                  <span className="text-sm font-medium">Scan Vulnerabilities</span>
                </button>
                <button className="flex flex-col items-center justify-center rounded-lg border border-border bg-background p-4 transition-colors hover:bg-muted">
                  <Activity className="h-8 w-8 text-primary mb-2" />
                  <span className="text-sm font-medium">View Reports</span>
                </button>
              </div>
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold mb-4">Terminal Access</h2>
            <div className="rounded-lg border border-border bg-card p-6">
              <div className="terminal h-[200px] overflow-auto text-sm">
                <div className="terminal-input">cd /opt/purpleteam</div>
                <div>Changed directory to /opt/purpleteam</div>
                <div className="terminal-input">ls -la</div>
                <div>
                  total 32<br />
                  drwxr-xr-x 6 root root 4096 Apr 10 15:23 .<br />
                  drwxr-xr-x 4 root root 4096 Apr 10 14:12 ..<br />
                  -rw-r--r-- 1 root root 2837 Apr 10 15:20 config.yml<br />
                  drwxr-xr-x 2 root root 4096 Apr 10 15:15 tools<br />
                  drwxr-xr-x 3 root root 4096 Apr 10 15:18 targets<br />
                  drwxr-xr-x 2 root root 4096 Apr 10 15:21 scripts<br />
                </div>
                <div className="terminal-input">./scripts/check_status.sh</div>
                <div className="terminal-success">
                  [+] Network status: ONLINE<br />
                  [+] Firewall status: ACTIVE<br />
                  [+] Target systems: 7 ONLINE, 0 OFFLINE<br />
                  [+] Monitoring: ACTIVE<br />
                </div>
                <div className="terminal-input">sudo nmap -sV 192.168.1.105</div>
                <div className="terminal-warning">
                  Starting Nmap 7.93 ( https://nmap.org ) at 2025-04-10 16:12 UTC<br />
                  Nmap scan report for target-105.lab.local (192.168.1.105)<br />
                  Host is up (0.0053s latency).<br />
                  Not shown: 994 closed ports<br />
                  PORT    STATE SERVICE    VERSION<br />
                  22/tcp  open  ssh        OpenSSH 8.9p1<br />
                  80/tcp  open  http       nginx 1.25.1<br />
                  443/tcp open  https      nginx 1.25.1<br />
                  3306/tcp open  mysql      MySQL 8.0.34<br />
                  8080/tcp open  http-proxy Apache Tomcat 10.1.13<br />
                  8443/tcp open  https-alt<br />
                </div>
                <div className="terminal-input">_</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;