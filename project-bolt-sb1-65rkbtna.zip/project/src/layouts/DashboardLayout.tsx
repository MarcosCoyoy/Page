import React, { useState } from 'react';
import { Outlet, Navigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  Shield, 
  Target, 
  LayoutDashboard, 
  FileText, 
  Settings, 
  LogOut, 
  Menu, 
  X, 
  ShieldAlert,
  Shield as ShieldIcon,
  List,
  AlertTriangle,
} from 'lucide-react';

const Sidebar: React.FC<{
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}> = ({ isMobileOpen, setIsMobileOpen }) => {
  const { pathname } = useLocation();
  const { user, logout } = useAuth();
  
  const navigation = [
    {
      name: 'Dashboard',
      href: '/dashboard',
      icon: LayoutDashboard,
      current: pathname === '/dashboard',
    },
    {
      name: 'Red Team',
      href: '/dashboard/red-team',
      icon: Target,
      current: pathname === '/dashboard/red-team',
      roles: ['admin', 'red-team', 'purple-team'],
    },
    {
      name: 'Blue Team',
      href: '/dashboard/blue-team',
      icon: Shield,
      current: pathname === '/dashboard/blue-team',
      roles: ['admin', 'blue-team', 'purple-team'],
    },
    {
      name: 'Exercises',
      href: '/dashboard/exercises',
      icon: List,
      current: pathname === '/dashboard/exercises',
    },
    {
      name: 'Vulnerabilities',
      href: '/dashboard/vulnerabilities',
      icon: AlertTriangle,
      current: pathname === '/dashboard/vulnerabilities',
    },
    {
      name: 'Reports',
      href: '/dashboard/reports',
      icon: FileText,
      current: pathname === '/dashboard/reports',
    },
    {
      name: 'Settings',
      href: '/dashboard/settings',
      icon: Settings,
      current: pathname === '/dashboard/settings',
      roles: ['admin'],
    },
  ];
  
  const filteredNavigation = navigation.filter(
    (item) => !item.roles || item.roles.includes(user?.role || '')
  );
  
  const sidebarClasses = `fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border transition-transform duration-300 ease-in-out ${
    isMobileOpen ? 'translate-x-0' : '-translate-x-full'
  } md:translate-x-0`;
  
  return (
    <>
      <div className={sidebarClasses}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <Link
              to="/dashboard"
              className="flex items-center space-x-2 text-xl font-bold"
            >
              <ShieldAlert className="h-8 w-8 text-primary" />
              <span>PurpleTeamLab</span>
            </Link>
            <button
              className="md:hidden text-muted-foreground hover:text-foreground"
              onClick={() => setIsMobileOpen(false)}
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto py-4">
            <nav className="space-y-1 px-2">
              {filteredNavigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    item.current
                      ? 'bg-primary/10 text-primary'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                  onClick={() => setIsMobileOpen(false)}
                >
                  <item.icon
                    className={`mr-3 h-5 w-5 flex-shrink-0 ${
                      item.current ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground'
                    }`}
                    aria-hidden="true"
                  />
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>
          
          <div className="p-4 border-t border-border">
            <div className="flex items-center">
              <img
                className="h-8 w-8 rounded-full"
                src={user?.avatar || 'https://i.pravatar.cc/150?u=default'}
                alt={user?.name || 'User'}
              />
              <div className="ml-3">
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-muted-foreground capitalize">{user?.role?.replace('-', ' ')}</p>
              </div>
              <button
                className="ml-auto text-muted-foreground hover:text-foreground"
                onClick={logout}
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Backdrop for mobile */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}
    </>
  );
};

const Header: React.FC<{
  setIsMobileOpen: (open: boolean) => void;
}> = ({ setIsMobileOpen }) => {
  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center bg-background/90 backdrop-blur-sm border-b border-border">
      <div className="flex items-center px-4 w-full">
        <button
          type="button"
          className="md:hidden inline-flex h-10 w-10 items-center justify-center rounded-md text-muted-foreground hover:text-foreground"
          onClick={() => setIsMobileOpen(true)}
        >
          <span className="sr-only">Open sidebar</span>
          <Menu className="h-6 w-6" aria-hidden="true" />
        </button>
        <div className="ml-4 md:ml-0 flex flex-1 justify-between">
          <div className="flex-1">
            <div className="relative flex w-full max-w-md">
              <div className="hidden sm:flex items-center">
                <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-muted text-muted-foreground">
                  <ShieldIcon className="h-5 w-5" />
                </span>
                <span className="ml-2 text-sm font-medium">Secure Lab Environment</span>
                <span className="ml-2 inline-flex h-6 items-center rounded-full bg-success/10 px-2 text-xs font-medium text-success">
                  Active
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <button
                type="button"
                className="relative rounded-full bg-muted p-1 text-muted-foreground hover:text-foreground focus:outline-none"
              >
                <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-accent animate-pulse"></span>
                <ShieldAlert className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

const DashboardLayout: React.FC = () => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-background">
        <div className="animate-spin text-primary">
          <ShieldAlert size={48} />
        </div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  
  return (
    <div className="min-h-screen bg-background">
      <Sidebar isMobileOpen={isMobileOpen} setIsMobileOpen={setIsMobileOpen} />
      
      <div className="md:pl-64">
        <Header setIsMobileOpen={setIsMobileOpen} />
        
        <main className="p-4 md:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;