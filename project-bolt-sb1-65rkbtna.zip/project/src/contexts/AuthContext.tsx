import React, { createContext, useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

interface User {
  id: string;
  username: string;
  role: 'admin' | 'red-team' | 'blue-team' | 'purple-team';
  name: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

const defaultContext: AuthContextType = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  logout: () => {},
};

const AuthContext = createContext<AuthContextType>(defaultContext);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  
  // Check if a user is already logged in
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    
    setIsLoading(false);
  }, []);
  
  // Mock login function for demo purposes
  const login = async (username: string, password: string) => {
    try {
      setIsLoading(true);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Demo credentials
      if (username === 'admin' && password === 'password') {
        const user: User = {
          id: '1',
          username: 'admin',
          role: 'admin',
          name: 'Admin User',
          avatar: 'https://i.pravatar.cc/150?u=admin',
        };
        
        setUser(user);
        localStorage.setItem('user', JSON.stringify(user));
        toast.success('Logged in successfully');
        navigate('/dashboard');
      } else if (username === 'red' && password === 'password') {
        const user: User = {
          id: '2',
          username: 'red',
          role: 'red-team',
          name: 'Red Team Member',
          avatar: 'https://i.pravatar.cc/150?u=red',
        };
        
        setUser(user);
        localStorage.setItem('user', JSON.stringify(user));
        toast.success('Logged in successfully');
        navigate('/dashboard');
      } else if (username === 'blue' && password === 'password') {
        const user: User = {
          id: '3',
          username: 'blue',
          role: 'blue-team',
          name: 'Blue Team Member',
          avatar: 'https://i.pravatar.cc/150?u=blue',
        };
        
        setUser(user);
        localStorage.setItem('user', JSON.stringify(user));
        toast.success('Logged in successfully');
        navigate('/dashboard');
      } else if (username === 'purple' && password === 'password') {
        const user: User = {
          id: '4',
          username: 'purple',
          role: 'purple-team',
          name: 'Purple Team Member',
          avatar: 'https://i.pravatar.cc/150?u=purple',
        };
        
        setUser(user);
        localStorage.setItem('user', JSON.stringify(user));
        toast.success('Logged in successfully');
        navigate('/dashboard');
      } else {
        toast.error('Invalid credentials');
      }
    } catch (error) {
      toast.error('Login failed');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    toast.success('Logged out successfully');
    navigate('/');
  };
  
  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};