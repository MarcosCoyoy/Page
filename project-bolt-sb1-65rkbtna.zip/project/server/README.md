# PurpleTeam Hacking Lab Backend

This directory contains the backend server code for the PurpleTeam Hacking Lab, designed to be deployed on AWS with Debian 12.

## Requirements

- Node.js 18+
- OpenSSL for generating self-signed certificates
- AWS CLI configured for deployment

## Setting up Self-Signed HTTPS

To generate self-signed certificates for your lab environment:

```bash
mkdir -p ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout ssl/private.key -out ssl/certificate.crt
```

When prompted, use your lab domain (e.g., `purpleteamlab.local` or your AWS instance domain name).

## Server Configuration

The backend server uses Express.js with the following security features:

- HTTPS with self-signed certificates
- JWT-based authentication
- Role-based access control
- API endpoints for red team and blue team operations
- WebSocket support for real-time notifications

## AWS Deployment

1. Provision an EC2 instance running Debian 12
2. Configure security groups to allow HTTPS traffic
3. Clone this repository to the instance
4. Install dependencies and generate certificates
5. Configure as a systemd service for automatic startup

## Security Considerations

This lab environment is designed for cybersecurity training and should be isolated from production networks. The self-signed certificates are appropriate for this purpose but would not be suitable for production applications.