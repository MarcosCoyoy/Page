import express from 'express';
import https from 'https';
import fs from 'fs';
import path from 'path';
import cors from 'cors';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Certificate paths
const SSL_KEY_PATH = path.join(__dirname, 'ssl', 'private.key');
const SSL_CERT_PATH = path.join(__dirname, 'ssl', 'certificate.crt');

// Create Express app
const app = express();

// Configure middleware
app.use(cors());
app.use(express.json());

// Check if certificates exist
function certificatesExist() {
  return fs.existsSync(SSL_KEY_PATH) && fs.existsSync(SSL_CERT_PATH);
}

// Generate self-signed certificates if they don't exist
function generateCertificates() {
  console.log('Certificates not found, please generate them first:');
  console.log('mkdir -p ssl');
  console.log('openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout ssl/private.key -out ssl/certificate.crt');
  process.exit(1);
}

// API routes
app.get('/api/status', (req, res) => {
  res.json({ 
    status: 'online',
    environment: 'secure lab',
    version: '1.0.0'
  });
});

// Start HTTPS server
const startServer = () => {
  if (!certificatesExist()) {
    generateCertificates();
    return;
  }
  
  try {
    const httpsOptions = {
      key: fs.readFileSync(SSL_KEY_PATH),
      cert: fs.readFileSync(SSL_CERT_PATH)
    };
    
    const server = https.createServer(httpsOptions, app);
    
    const PORT = process.env.PORT || 3000;
    server.listen(PORT, () => {
      console.log(`Secure PurpleTeam Lab server running on https://localhost:${PORT}`);
    });
    
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1);
  }
};

startServer();